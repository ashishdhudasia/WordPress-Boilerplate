<?php
/**
 * Single page settings page
 *
 * @package HeaderFooterElementor
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div id="schema-settings-app" class="schema-settings-app">
</div>
