<?php
/**
 * Dashboard page template.
 *
 * @package    RankMath
 * @subpackage RankMath\Admin
 */

defined( 'ABSPATH' ) || exit;

// Header.
rank_math()->admin->display_admin_header( false );
?>
<div class="wrap rank-math-wrap dashboard" id="rank-math-dashboard-page"></div>
